import { Address, toNano } from '@ton/core';

export * from './mainnet';
export * from './testnet';

export const NULL_ADDRESS = Address.parse('UQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJKZ');

export const ASSET_PRICE_SCALE = BigInt(1e9);

export const MASTER_CONSTANTS = {
    FACTOR_SCALE: BigInt(1e12),
    ASSET_COEFFICIENT_SCALE: 10000n,
    ASSET_PRICE_SCALE,
    ASSET_RESERVE_FACTOR_SCALE: 10000n,
    ASSET_LIQUIDATION_RESERVE_FACTOR_SCALE: 10000n,
    ASSET_ORIGINATION_FEE_SCALE: BigInt(1e9),
    ASSET_LIQUIDATION_THRESHOLD_SCALE: 10_000n,
    ASSET_LIQUIDATION_BONUS_SCALE: 10_000n,
    ASSET_SRATE_SCALE: BigInt(1e12),
    ASSET_BRATE_SCALE: BigInt(1e12),
    COLLATERAL_WORTH_THRESHOLD: 100n * ASSET_PRICE_SCALE, // literally 100$
};

export const OPCODES = {
    // General
    ONCHAIN_GETTER: 0x9998,

    // Supply
    SUPPLY_MASTER: 0x1,
    SUPPLY_USER: 0x11,
    SUPPLY_SUCCESS: 0x11a,
    SUPPLY_FAIL: 0x11f,
    SUPPLY_EXCESS: 0x11ae,
    SUPPLY_SUCCESS_AND_REPAY_REMAININGS: 0x11ab,
    SUPPLY_FAIL_EXCESS: 0x11ae1,
    SUPPLY_FAIL_REVERT: 0x11ae2,

    // Liquidate
    LIQUIDATE_MASTER: 0x3,
    LIQUIDATE_MASTER_JETTON_PROCESS: 0x32,
    LIQUIDATE_USER: 0x31,
    LIQUIDATE_UNSATISFIED: 0x31f,
    LIQUIDATE_SATISFIED: 0x311,
    LIQUIDATE_SUCCESS: 0x311a,
    LIQUIDATE_SUCCESS_REPORT: 0x311d,
    LIQUIDATE_FAIL: 0x311f,
    LIQUIDATE_FAIL_REVERT: 0x211fe91,

    // Supply & Withdraw
    SUPPLY_WITHDRAW_MASTER: 0x4,
    SUPPLY_WITHDRAW_MASTER_WITHOUT_PRICES: 0x401,
    SUPPLY_WITHDRAW_MASTER_JETTON: 0x42,
    SUPPLY_WITHDRAW_USER: 0x41,
    SUPPLY_WITHDRAW_SATISFIED: 0x411,
    SUPPLY_WITHDRAW_SATISFIED_AND_REPAY_REMAININGS: 0x411b,
    SUPPLY_WITHDRAW_UNSATISFIED: 0x41f,
    SUPPLY_WITHDRAW_FAIL: 0x411f,
    SUPPLY_WITHDRAW_SUCCESS: 0x411a,

    // Reward
    REWARD_CLAIM: 0x2,
    REWARD_TON_TOP_UP: 0x7362d09c,
    REWARD_JETTON_MINT: 0x178d4519,
    REWARD_JETTON_TRANSFER: 0x0f8a7ea5,

    // TEP's
    JETTON_TRANSFER: 0xf8a7ea5,
};

export const FEES = {
    // General
    JETTON_FWD: toNano('0.05'),

    // Supply
    SUPPLY: toNano('0.25'),

    // Supply & Withdraw
    SUPPLY_WITHDRAW: toNano('0.48'),

    // Liquidation
    LIQUIDATION: toNano('0.8'),
    LIQUIDATION_JETTON: toNano('1'),
    LIQUIDATION_JETTON_FWD: toNano('0.8'),

    // Reward
    REWARD_MASTER_TON_TOP_UP: toNano('0.03'),
    REWARD_MASTER_DEPLOY: toNano('0.05'),
    REWARD_MASTER_WITHDRAW: toNano('0.1'),
    REWARD_USER_DEPLOY: toNano('0.05'),
    REWARD_USER_CLAIM: toNano('0.1'),
} as const;

/**
 * Common validation constants and error messages
 */
export const VALIDATION = {
    ERRORS: {
        INVALID_AMOUNT: 'Amount must be positive',
        INVALID_SUBACCOUNT_ID: 'Subaccount ID must be between 0 and 255',
        MISSING_JETTON_AMOUNT: 'Either amount, liquidationAmount, or supplyAmount must be provided',
        MISSING_RESPONSE_ADDRESS: 'responseAddress, userAddress, or liquidatorAddress must be provided',
        INVALID_ASSET_CONFIG: 'Invalid asset configuration provided',
        MASTER_CONTRACT_INACTIVE: 'Master contract is not active',
        OUTDATED_SDK_VERSION: 'Outdated SDK pool version',
    } as const,
} as const;
