import { Address, beginCell, Cell, storeStateInit } from '@ton/core';
import { PoolAssetConfig } from '../types/Master';
import { UNDEFINED_ASSET } from '../constants/assets';
import { calculateCloseAddress } from './fivaUtils';

function getUserJettonData(ownerAddress: Address, assetName: string, jettonWalletCode: Cell, jettonMasterAddress: Address) {
  switch (assetName) {
      case 'DOGS':
      case 'NOT':
      case 'USDT':
      case 'USDe':
          return beginCell()
              .storeUint(0, 4)
              .storeCoins(0)
              .storeAddress(ownerAddress)
              .storeAddress(jettonMasterAddress)
              .endCell();
      case 'PT_tsUSDe_01Sep2025':
      case 'PT_tsUSDe_18Dec2025':
        return beginCell()
              .storeCoins(0)
              .storeAddress(ownerAddress)
              .storeAddress(jettonMasterAddress)
              .endCell();
      case 'tsUSDe':
        return beginCell()
          .storeUint(0, 4)
          .storeCoins(0)
          .storeAddress(ownerAddress)
          .storeAddress(jettonMasterAddress)
          .storeCoins(0)
          .storeUint(0, 64)
          .endCell();
      case 'tsTON':
          return beginCell()
              .storeCoins(0)
              .storeAddress(ownerAddress)
              .storeAddress(jettonMasterAddress)
              .storeRef(jettonWalletCode)
              .storeCoins(0)
              .storeUint(0, 48)
              .endCell();
      case 'tgBTC':
          return beginCell()
              .storeUint(0, 4)
              .storeCoins(0)
              .storeAddress(ownerAddress)
              .storeAddress(jettonMasterAddress)
              .endCell();
      default:
          return beginCell().storeCoins(0)
              .storeAddress(ownerAddress)
              .storeAddress(jettonMasterAddress)
              .storeRef(jettonWalletCode)
              .endCell();
  }
}
export function getUserJettonWallet(ownerAddress: Address, poolAssetConfig: PoolAssetConfig) {
  const assetName = poolAssetConfig.name;
  if (assetName == 'TON' || poolAssetConfig.assetId === UNDEFINED_ASSET.assetId) {
    throw new Error(`Cant getUserJettonWallet for ${poolAssetConfig.name} asset`)
  }
  let jettonWalletCode = poolAssetConfig.jettonWalletCode;

  if (assetName === 'USDT' || assetName === 'tsTON') {
    const lib_prep = beginCell().storeUint(2, 8).storeBuffer(jettonWalletCode.hash()).endCell();
    jettonWalletCode = new Cell({ exotic: true, bits: lib_prep.bits, refs: lib_prep.refs });
  }

  const jettonData = getUserJettonData(ownerAddress, assetName, jettonWalletCode, poolAssetConfig.jettonMasterAddress);

  let stateInit = beginCell()
    .store(
      storeStateInit({
        code: jettonWalletCode,
        data: jettonData
      })
    )
    .endCell();

    
   if (poolAssetConfig.name === 'PT_tsUSDe_18Dec2025') {
     stateInit = beginCell()
      .storeUint(1, 1)   // fixed_prefix_length
      .storeUint(8, 5)   // rewrite_bits
      .storeUint(0, 1)   // special (Maybe=0)
      .storeMaybeRef(jettonWalletCode)  // code (Maybe)
      .storeMaybeRef(jettonData)               // data (Maybe)
      .storeUint(0, 1)   // libraries empty
      .endCell();

      const addr = new Address(0, stateInit.hash());
      return calculateCloseAddress(addr, poolAssetConfig.jettonMasterAddress);
    }

  return new Address(0, stateInit.hash());
}
