import { Address, Cell, Dictionary } from '@ton/core';
import { AbstractCollector } from '../oracles';
export { FeedMapItem, parseFeedsMapDict } from '../api/feeds';

export type MasterConstants = {
    FACTOR_SCALE: bigint;
    ASSET_COEFFICIENT_SCALE: bigint;
    ASSET_PRICE_SCALE: bigint;
    ASSET_RESERVE_FACTOR_SCALE: bigint;
    ASSET_LIQUIDATION_RESERVE_FACTOR_SCALE: bigint;
    ASSET_LIQUIDATION_THRESHOLD_SCALE: bigint;
    ASSET_LIQUIDATION_BONUS_SCALE: bigint;
    ASSET_ORIGINATION_FEE_SCALE: bigint;
    ASSET_SRATE_SCALE: bigint;
    ASSET_BRATE_SCALE: bigint;
    COLLATERAL_WORTH_THRESHOLD: bigint;
};

export type PoolAssetConfig = {
    name: string;
    assetId: bigint;
    jettonMasterAddress: Address;
    jettonWalletCode: Cell;
};

export type PoolConfig = {
    masterAddress: Address;
    masterVersion: number;
    masterConstants: MasterConstants;
    poolAssetsConfig: PoolAssetConfig[];
    lendingCode: Cell;
    collector: AbstractCollector;
};

export type UpgradeConfig = {
    masterCodeVersion: number;
    userCodeVersion: number;
    timeout: number;
    updateTime: number;
    freezeTime: number;
    userCode: Cell;
    //blankCode: Cell;
    newMasterCode: Cell | null;
    newUserCode: Cell | null;
};

export type AssetConfig = {
    jwAddress: bigint;
    decimals: bigint;
    collateralFactor: bigint;
    liquidationThreshold: bigint;
    liquidationBonus: bigint;
    baseBorrowRate: bigint;
    borrowRateSlopeLow: bigint;
    borrowRateSlopeHigh: bigint;
    supplyRateSlopeLow: bigint;
    supplyRateSlopeHigh: bigint;
    targetUtilization: bigint;
    originationFee: bigint;
    dust: bigint;
    maxTotalSupply: bigint;
    reserveFactor: bigint;
    liquidationReserveFactor: bigint;
    minPrincipalForRewards: bigint;
    baseTrackingSupplySpeed: bigint;
    baseTrackingBorrowSpeed: bigint;
    borrowCap: number | bigint;
    heCategory: number;
    heCollateralFactor: number;
    heLiquidationThreshold: number;
};

export type AssetData = {
    sRate: bigint;
    bRate: bigint;
    totalSupply: bigint;
    totalBorrow: bigint;
    lastAccrual: bigint;
    balance: bigint;
    trackingSupplyIndex: bigint;
    trackingBorrowIndex: bigint;
    awaitedSupply: bigint;
};

export type AssetInterest = {
    supplyInterest: bigint;
    borrowInterest: bigint;
};

export type AssetApy = {
    supplyApy: number;
    borrowApy: number;
};

export type ExtendedAssetData = AssetData & AssetInterest & AssetApy;
export type ExtendedAssetsData = Dictionary<bigint, ExtendedAssetData>;
export type ExtendedAssetsConfig = Dictionary<bigint, AssetConfig>;

export type AgregatedBalances = {
    totalBorrow: bigint;
    totalSupply: bigint;
};

export type ExtendedEvaaOracle = EvaaOracle & {
    address: string;
};

export type EvaaOracle = {
    id: number;
    pubkey: Buffer;
};
